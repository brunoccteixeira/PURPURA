def build_index():
    pass
