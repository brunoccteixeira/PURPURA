def verify(payload):
    return True
