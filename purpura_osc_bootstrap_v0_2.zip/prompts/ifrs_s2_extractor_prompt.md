{{json_schema}}

{{evidence_chunks}}

{{task_description}}
