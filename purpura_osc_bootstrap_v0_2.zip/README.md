# PÚRPURA × OS-Climate — Bootstrap v0.2

MVP para IFRS S2 com LLM+RAG, Trino/Iceberg e Superset.
